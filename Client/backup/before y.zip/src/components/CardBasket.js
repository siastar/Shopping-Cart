import React from 'react';
import './CardComponents.css'
import AccordionBasket from './Accordion/AccordionBasket.js'

class CardBasket extends React.Component{
    
    render() {

        console.log('card basket this: ', this);
        //returns this-props.data{...}
        return (
           
            <div className='basket'>
              <hr/>
              <AccordionBasket/>
              <p> id {this.props.data.id} </p>
              <p> product: {this.props.data.title} </p>
              <p> price: € {this.props.data.price * this.props.data.qt} </p>
              <p> qt {this.props.data.qt} </p>
            </div>

        );
    }
}
export default CardBasket;

