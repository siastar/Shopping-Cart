import React from 'react';

import {
    Accordion,
    AccordionItem,
    AccordionItemHeading,
    AccordionItemPanel,
    AccordionItemButton
}from 'react-accessible-accordion';

import 'react-accessible-accordion/dist/fancy-example.css';

//import './App.css';

class AccordionBasket extends React.Component{ 

    accordionBox()
    {
        const test='Donald Duck';
        console.log('accordionBox', test);
        return(
            <div>
              <div className="accordion-container">
                 <div className="ac">
                   <div className="ac-a">
                     <Accordion>
                       <AccordionItem>
                         <AccordionItemHeading>
                           <AccordionItemButton>
                             What harsh truths do you prefer to ignore? {test}
                           </AccordionItemButton>
                         </AccordionItemHeading>
                         <AccordionItemPanel>
                           <p>
                             Exercitation in fugiat est ut ad ea cupidatat ut in
                             cupidatat occaecat ut occaecat consequat est minim minim
                             esse tempor laborum consequat esse adipisicing eu
                             reprehenderit enim.
                           </p>
                         </AccordionItemPanel>
                       </AccordionItem>
                     </Accordion>
                   </div>
                 </div>
               </div>             
            </div>
        )
    }


    render (){
        return (
            <p> ...stuff {this.accordionBox()}</p>
            

        )       
    }    
}
export default AccordionBasket;
