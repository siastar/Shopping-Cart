import React from 'react';
import CardBrowseButton from './CardBrowseButton.js'

class CardNavbar extends React.Component{

    render() {
        console.log('CardNavbar this is: ', this);
        console.log('CardNavbar index is:', this.props.index);
        
        return (
            <div className='navbar'>
              <CardBrowseButton
                getButtonType={this.props.getButtonType}
                buttonType='prev'
              />
              
              <p> ... </p>
              <CardBrowseButton
                getButtonType={this.props.getButtonType}
                buttonType='next'
              />
            </div>
        );
    }
}
export default CardNavbar;









