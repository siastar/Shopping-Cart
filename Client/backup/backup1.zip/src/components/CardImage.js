import React from 'react';
import picture from './../DB/imgDataBase/prod001/img01.jpg'
//import './App.css';

function CardImage() {
    return (
      <div className='imgdiv'>
         <img src={picture} alt="missing image"/>
      </div>
  );
}
export default CardImage;
