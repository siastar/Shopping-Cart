import React from 'react';
import './CardComponents.css'

function CardButton() {
  return (
      <div className='button'>
        <button

          onClick={console.log('added to cart')}
        >
          add to cart
        </button>
        <p>number</p>
        <p>tot price</p>
      </div>
  );
}

export default CardButton;

