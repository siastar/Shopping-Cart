const productDataBase = [
    {
        id: 1,
        title: 'The Best Thing',
        imgPath: './img/prod001/',
        description: 'product number one, is the number one for alpacas !!!',
        price: 66.50,        
    },
     {
        id: 2,
        title: 'The Super Stuff',
        imgPath: './img/prod002/',
        description: 'product number two, the best product for your squirrel !!!',
        price: 149.75,        
     },
     {
        id: 3,
        title: 'The Mega Cool',
        imgPath: './img/prod003/',
        description: 'give your turtle product number three !!!!',
        price: 19.15,        
     },
     {
        id: 4,
        title: 'The Ultra Stuff',
        imgPath: '',
        description: 'give your emu a lovely product number four !!!!',
        price: 24.65        
    },
    {
        id: 5,
        title: 'The Space Fun',
        imgPath: '',
        description: 'your platypus will enjoy product number five !!!!',
        price: 41.35,        
    }
]

export default productDataBase
