import React from 'react';
import CardAddButton from './CardAddButton.js'
import Basket from './CardBasket.js'
import './CardComponents.css'


class CardShoppingPanel extends React.Component{

    showShop() {
        console.log('showShop working...');
        return(<p> reached !!!</p> );
    }


    
    render() {
        
        console.log('shopping panel, this: ', this.props);
        console.log('shopping panel, cart: ', this.props.cart);

        const shopper = this.props.cart.map(
            product => <Basket />
            
        )

        console.log('shopper: ', shopper);
        
        return (
            <div className='shoppingpanel'>
              <h4> shopping panel</h4>
              <CardAddButton
                handleCartButton={this.props.handleCartButton}/>
              <p> {shopper} </p>              
            </div>           
        );
    }
}
export default CardShoppingPanel;



