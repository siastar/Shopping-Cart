import React from 'react';
import './CardComponents.css'


class CardBasket extends React.Component{


    
    render() {
                
        return (
            <div className='shoppingpanel'>
              <h6> your basket </h6>
              
            </div>

            



        );
    }
}
export default CardBasket;

