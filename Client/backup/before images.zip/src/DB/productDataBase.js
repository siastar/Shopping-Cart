const productDataBase = [
    {
        id: 1,
        title: 'The Best Thing',
        imgPath: './imgDataBase/prod001/img01.jpg',
        description: 'product number one, is the number one for alpacas !!! Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum consequat sem ex, sed sagittis nunc vulputate ut. Duis egestas odio vel dapibus condimentum. Nulla molestie urna a iaculis congue. Suspendisse consequat nibh diam, nec hendrerit orci tempus non. Vivamus at sodales dolor. Proin maximus mauris elit, non accumsan magna aliquam. ',
        price: 66.50,        
    },
     {
        id: 2,
        title: 'The Super Stuff',
        imgPath: './imgDataBase/prod002/img01.jpg',
        description: 'Product number two, the best product for your squirrel !!! Consectetur adipiscing elit. Vestibulum consequat sem ex, sed sagittis nunc vulputate ut. Duis egestas odio vel dapibus condimentum. Nulla molestie urna a iaculis congue. Suspendisse consequat nibh diam, nec hendrerit orci tempus non. Vivamus at sodales dolor. Proin maximus mauris elit, non accumsan magna aliquam. ',
        price: 149.75,        
     },
     {
        id: 3,
        title: 'The Mega Cool',
        imgPath: './imgDataBase/prod003/img01.jpg',
        description: 'give your turtle product number three !!!! Duis egestas odio vel dapibus condimentum. Nulla molestie urna a iaculis congue. Suspendisse consequat nibh diam, nec hendrerit orci tempus non. Vivamus at sodales dolor. Proin maximus mauris elit, non accumsan magna aliquam. ',
        price: 19.15,        
     },
     {
        id: 4,
        title: 'The Ultra Stuff',
        imgPath: './imgDataBase/prod004/img01.jpg',
        description: 'Give your emu a lovely product number four !!!!, Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum consequat sem ex, sed sagittis nunc vulputate ut. Duis egestas odio vel dapibus condimentum. Nulla molestie urna a iaculis congue. Suspendisse consequat nibh diam, nec hendrerit orci tempus non. Vivamus at sodales dolor. Proin maximus mauris elit, non accumsan magna aliquam. ',
        price: 24.65        
    },
    {
        id: 5,
        title: 'The Space Fun',
        imgPath: './imgDataBase/prod005/img01.jpg',
        description: 'Your platypus will enjoy product number five !!!! Vestibulum consequat sem ex, sed sagittis nunc vulputate ut. Duis egestas odio vel dapibus condimentum. Nulla molestie urna a iaculis congue. Suspendisse consequat nibh diam, nec hendrerit orci tempus non. Vivamus at sodales dolor. Proin maximus mauris elit, non accumsan magna aliquam. ',
        price: 41.35,        
    }
]

export default productDataBase
