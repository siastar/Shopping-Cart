const productDataBase = [
    {
        id: 1,
        title: 'The Best Thing',
        imgPath: './imgDataBase/prod001/img01.jpg',
        description: 'product number one, is the number one for alpacas !!!',
        price: 66.50,        
    },
     {
        id: 2,
        title: 'The Super Stuff',
        imgPath: './imgDataBase/prod002/img01.jpg',
        description: 'product number two, the best product for your squirrel !!!',
        price: 149.75,        
     },
     {
        id: 3,
        title: 'The Mega Cool',
        imgPath: './imgDataBase/prod003/img01.jpg',
        description: 'give your turtle product number three !!!!',
        price: 19.15,        
     },
     {
        id: 4,
        title: 'The Ultra Stuff',
        imgPath: './imgDataBase/prod004/img01.jpg',
        description: 'give your emu a lovely product number four !!!!',
        price: 24.65        
    },
    {
        id: 5,
        title: 'The Space Fun',
        imgPath: './imgDataBase/prod005/img01.jpg',
        description: 'your platypus will enjoy product number five !!!!',
        price: 41.35,        
    }
]

export default productDataBase
