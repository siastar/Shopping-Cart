//components
import React from 'react';
import CardNavbar from './CardNavbar.js';
import CardTitle from './CardTitle.js';
import CardImage from './CardImage.js';
import CardDescription from './CardDescription.js';
import CardPrice from './CardPrice.js';
import CardButton from './CardButton.js';
//dataBase
import productDataBase from './../DB/productDataBase.js'
//style
import './CardComponents.css';

class CardContainer extends React.Component {
    constructor() {
        super()
        this.state={
            productIndex: 3,
            buttonType: '',
            check: 'state reached!',
            productDB: productDataBase
        }
    }

    showStuff(){
        let index=this.state.productIndex;
        let toShow = this.state.productDB[index]; //the actual "product object" contained in the DB array (json)
        return(toShow);
        //showStuff send to the components the "product object" (toShow) by picking it from its
        //own position (index) in the array in the product database array.

    }

    getButtonType = (buttonType) => {
        console.log('buttontype is: ', buttonType);
        let indexMod=0;
        //according to the pressed button provide a 'next' or 'prev' value +1 or -1 (indexMod) to increase or decrease the
        //the index determines the showed object in the database array
        if (buttonType === 'prev'){indexMod = -1}
        if (buttonType === 'next'){indexMod = 1}
        console.log('indexMod:', indexMod)
        // at this point we need to change the productIndex in the state in order to change the visualized product
        // to do this we need to update the state by using setState and indexMod

        // 1st  we grab the current productIndex in state
        let currentIndex = this.state.productIndex;
        console.log('currentIndex: ', currentIndex)
        // 2nd we modify currentIndex with indexMod which could be +1 or -1 according to the next or prev button parameters
        let newIndex = currentIndex + indexMod;
        console.log('new index before range check: ',newIndex);
        // 3rd we update the state to replace current index with new index value
        // this.setState({productIndex: newIndex});
        
        // but it come out a problem, what if newIndex goes out of the productDB array index range? dafaq!?! 
        // case of newIndex is less than zero or greater than array length:
        // productDB index range is 0 - this.state.productDB.length.
        // what we need before to update the state is:
        // turn newIndex to 0 if it exceeds productDB.length
        // turn newIndex to productDB.lenght if it goes lesser than 0
        // this way we should be able to cycle the indexes forward 0-1-2-0-1-2... or backward 0-2-1-0-2-1...
        // LAST BUT NOT LEAST remember that array index goes from 0 for the 1st element to (length -1) for the last element 
        // [element 1, element 2, element 3, ... , element n]
        //  index 0    endex 1    index 2   ....   index n-1
        // so our maxIndex will be (array-length -1);
        
        let maxIndex = (this.state.productDB.length -1);
        console.log('array dimension:', maxIndex);
        if (newIndex > maxIndex) {
            console.log('greater than range');
            newIndex = 0; // turn newIndex to 0 if it exceeds productDB.length
        }
        else if (newIndex < 0) {
            console.log('lesser than range')
            newIndex = maxIndex; //turn newIndex to productDB.lenght if it goes lesser than 0
        }
        else {
            console.log('newIndex' , newIndex , 'is ranged')
        }

        this.setState({productIndex: newIndex});
        console.log('updated product index is: ', this.state.productIndex);
    }    
      
    render(){
       // console.log('parent this is: ', this)
       // console.log('checking the state access from CardContainer...' , this.state.check)        
       // for (let i=0; i<=2; i++){ console.log('checking  DB access from CardContainer...', this.state.productDB[i].description);}

        return (
            <div className='cardcontainer'>

              <p>hello</p>
              <h4> {this.state.check} </h4>
              <h4> index {this.state.productIndex} </h4>

              <CardNavbar
                getButtonType={this.getButtonType} /* callback function */
                index={this.state.productIndex}
                data={this.showStuff()}
              />
              
              <CardTitle
                data={this.showStuff()}
              />
              <CardImage
                data={this.showStuff()} 
             /> 
              <CardDescription
                data={this.showStuff()}
              />
              <CardPrice
                data={this.showStuff()}
              />
              <CardButton
                
              />
            </div>            
        );
    }
}

export default CardContainer;
