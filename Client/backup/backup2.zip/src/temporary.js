
const archive =[

    {id: 1,
     value:'test value 1'        
    },
    {id: 2,
     value:'test value 2'        
    },
    {id: 3,
     value:'test value 3'        
    },
    {id: 4,
     value:'test value 4'        
    },
    {id: 5,
     value:'test value 5'        
    },
    {id: 6,
     value:'test value 6'        
    },
]

console.log(archive);

let termOfSearch = 3;

let pos = archive.map(function(e) { return e.id; }).indexOf(termOfSearch);

console.log('the index you are looking for is: ', pos);
