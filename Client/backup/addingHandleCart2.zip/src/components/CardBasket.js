import React from 'react';
import './CardComponents.css'
import CartModButton from './CartModButton.js'
import AccordionBasket from './Accordion/AccordionBasket.js'

class CardBasket extends React.Component{


    // sendButtonType = () =>{
    //     console.log('sendButtonType called: ');
    //     this.props.onCartModify(this.props.buttonType);
    //     // calls back onCartModify  from the (grand)parent and passes it the buttonType value (add || remove)
    //     // received from the parent ( CardContainer -> CardShoppingPanel -> CardBrowsebutton )
    // }



    
    render() {

        console.log('CardBasket this.props: ', this.props);
        //returns this-props.data{...}
        return (
           
            <div className='basket'>

              <AccordionBasket
                data={this.props.data}
              />
              
              <CartModButton
                buttonType='-'
                cartIndex={this.props.cartIndex}
                onCartModify={this.props.onCartModify}
               />
                                     
              <CartModButton
                buttonType='+'
                cartIndex={this.props.cartIndex}
                onCartModify={this.props.onCartModify}                       
              />
                              
            </div>

        );
    }
}
export default CardBasket;

