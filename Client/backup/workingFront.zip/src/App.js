import React from 'react';
import CardContainer from './components/CardContainer.js';

function App() {
    //console.log('Cardcontainer has access to:', this.state.check);  
  return (
      <div>
        <CardContainer />
      </div>
  );
}

export default App;
