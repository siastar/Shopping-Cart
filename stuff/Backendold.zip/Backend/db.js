const mongoose = require ('mongoose');

class appDbManager {

    constructor() {
        this.productSchema = new Schema( {
            id: Number,
            title: String,
            description: String,
            price: Number
        });

        mongoose.connect('mongodb://localhost:27017/products');

        this.Product = mongoose.model('Product' , this.productSchema);
    }

    getProducts (){
        this.Product.find((err, data) => {
            if (err) return(console.error(err));
            console.log(data);
        }
            
     );
        
    }
    
    getProductSchema(){
        return this.productSchema;
    }
}
