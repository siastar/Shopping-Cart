db.inventory.insertMany( [
    {
        id: 1,
        title: 'The Best Thing',
        imgPath: './imgDataBase/prod001/img01.jpg',
        description: 'product number one, is the number one for alpacas !!! Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum consequat sem ex, sed sagittis nunc vulputate ut. Duis egestas odio vel dapibus condimentum. Nulla molestie urna a iaculis congue. Suspendisse consequat nibh diam, nec hendrerit orci tempus non. Vivamus at sodales dolor. Proin maximus mauris elit, non accumsan magna aliquam. ',
        price: 66.50,        
    },
    {
        id: 2,
        title: 'The Super Stuff',
        imgPath: './imgDataBase/prod002/img02.jpg',
        description: 'Product number two, the best product for your squirrel !!! Consectetur adipiscing elit. Vestibulum consequat sem ex, sed sagittis nunc vulputate ut. Duis egestas odio vel dapibus condimentum. Nulla molestie urna a iaculis congue. Suspendisse consequat nibh diam, nec hendrerit orci tempus non. Vivamus at sodales dolor. Proin maximus mauris elit, non accumsan magna aliquam. ',
        price: 149.75,        
    },
    {
        id: 3,
        title: 'The Mega Cool',
        imgPath: './imgDataBase/prod003/img03.jpg',
        description: 'give your turtle product number three !!!! Duis egestas odio vel dapibus condimentum. Nulla molestie urna a iaculis congue. Suspendisse consequat nibh diam, nec hendrerit orci tempus non. Vivamus at sodales dolor. Proin maximus mauris elit, non accumsan magna aliquam. ',
        price: 19.15,        
    },
    {
        id: 4,
        title: 'The Ultra Stuff',
        imgPath: './imgDataBase/prod004/img04.jpg',
        description: 'Give your emu a lovely product number four !!!!, Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum consequat sem ex, sed sagittis nunc vulputate ut. Duis egestas odio vel dapibus condimentum. Nulla molestie urna a iaculis congue. Suspendisse consequat nibh diam, nec hendrerit orci tempus non. Vivamus at sodales dolor. Proin maximus mauris elit, non accumsan magna aliquam. ',
        price: 24.65        
    },
    {
        id: 5,
        title: 'The Space Fun',
        imgPath: './imgDataBase/prod005/img05.jpg',
        description: 'Your platypus will enjoy product number five !!!! Vestibulum consequat sem ex, sed sagittis nunc vulputate ut. Duis egestas odio vel dapibus condimentum. Nulla molestie urna a iaculis congue. Suspendisse consequat nibh diam, nec hendrerit orci tempus non. Vivamus at sodales dolor. Proin maximus mauris elit, non accumsan magna aliquam. ',
        price: 88.25,        
    },
    {
        id: 6,
        title: 'The Amazing Solution',
        imgPath: './imgDataBase/prod006/img06.jpg',
        description: 'Happy doggos with offer number Six !!!! Vestibulum consequat sem ex, sed sagittis nunc vulputate ut. Duis egestas odio vel dapibus condimentum. Nulla molestie urna a iaculis congue. Suspendisse consequat nibh diam, nec hendrerit orci tempus non. Vivamus at sodales dolor. Proin maximus mauris elit, non accumsan magna aliquam. ',
        price: 41.35,        
    },
    {
        id: 7,
        title: 'Better than Best',
        imgPath: './imgDataBase/prod007/img07.jpg',
        description: 'Your Froggo will love this offer number Seven !!!! Vestibulum consequat sem ex, sed sagittis nunc vulputate ut. Duis egestas odio vel dapibus condimentum. Nulla molestie urna a iaculis congue. Suspendisse consequat nibh diam, nec hendrerit orci tempus non. Vivamus at sodales dolor. Proin maximus mauris elit, non accumsan magna aliquam. ',
        price: 49.31,        
    },
    {
        id: 8,
        title: 'Wonder Wonder',
        imgPath: './imgDataBase/prod008/img08.jpg',
        description: 'Everybody wants the kung fu fighting number Eight !!!! Vestibulum consequat sem ex, sed sagittis nunc vulputate ut. Duis egestas odio vel dapibus condimentum. Nulla molestie urna a iaculis congue. Suspendisse consequat nibh diam, nec hendrerit orci tempus non. Vivamus at sodales dolor. Proin maximus mauris elit, non accumsan magna aliquam. ',
        price: 41.35,        
    },
    {
        id: 9,
        title: 'At the Top of the Tap',
        imgPath: './imgDataBase/prod009/img09.jpg',
        description: 'Tap like a pro with professional tapper number Nine !!!! Vestibulum consequat sem ex, sed sagittis nunc vulputate ut. Duis egestas odio vel dapibus condimentum. Nulla molestie urna a iaculis congue. Suspendisse consequat nibh diam, nec hendrerit orci tempus non. Vivamus at sodales dolor. Proin maximus mauris elit, non accumsan magna aliquam. ',
        price: 61.15,        
    },
    {
        id: 10,
        title: 'The Ultimate Mate',
        imgPath: './imgDataBase/prod010/img10.jpg',
        description: 'After the ultimate mate you will mate at higher rate !!!! Vestibulum consequat sem ex, sed sagittis nunc vulputate ut. Duis egestas odio vel dapibus condimentum. Nulla molestie urna a iaculis congue. Suspendisse consequat nibh diam, nec hendrerit orci tempus non. Vivamus at sodales dolor. Proin maximus mauris elit, non accumsan magna aliquam. ',
        price: 55.25,        
    }
]
)


db.inventory.insertOne(
    { id: 0,
      title: 'test title',
      imgPath:'./test Path',
      description:'test description',
      price: 0}
)
